package bgu.spl.net;

import java.util.List;

public class Student extends User {
    public Student (String userName,String password){
        super(userName , password);
    }

}
